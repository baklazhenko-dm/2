from typing import Optional
from pydantic import BaseModel, Field


class NewNote(BaseModel):
    """
    Новая пользовательская заметка
    """

    title: Optional[str] = Field(description='Заголовок заметки', max_length=300)
    content: str = Field(description='Содержимое заметки', max_length=1500)

    class Config:
        title = 'Новая заметка'
        schema_extra = {
            'example': {
                'title': 'Покупки в магазине',
                'content': 'Купить лимон и чай'
            }
        }

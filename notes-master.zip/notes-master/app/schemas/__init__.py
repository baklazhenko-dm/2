from typing import Optional

from pydantic import BaseModel, Field


class Note(BaseModel):
    """
    Заметка, которую пользователь может создать, получить и фильтровать
    """
    id: int = Field(description='Идентификатор заметки')
    title: Optional[str] = Field(description='Заголовок заметки', max_length=200)
    content: str = Field(description='Текст заметки', max_length=1500)

    class Config:
        title = 'Заметка'
        schema_extra = {
            'example': {
                'id': 1,
                'title': 'Сходить в магазин',
                'content': 'Купить лимон и лук'
            }
        }

from typing import Optional
from pydantic import BaseModel, Field


class Note(BaseModel):
    """
    Пользовательская заметка
    """
    id: int = Field(description='Уникальный идентификатор заметки')
    title: str = Field(description='Заголовок заметки', max_length=300)
    content: str = Field(description='Содержимое заметки', max_length=1500)

    class Config:
        title = 'Заметка'
        schema_extra = {
            'example': {
                'id': 1,
                'title': 'Покупки в магазине',
                'content': 'Купить лимон и чай'
            }
        }

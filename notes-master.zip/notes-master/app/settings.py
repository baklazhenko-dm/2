import os

LOG_FORMAT = '[%(name)s] [%(process)d] [%(levelname)s] %(message)s'
LOG_LEVEL = os.environ.get('LOG_LEVEL', 'INFO')

TITLE_FROM_CONTENT_LEN = 5
DB_NAME = 'db.sqlite3'

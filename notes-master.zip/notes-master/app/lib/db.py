from typing import Optional, Iterable
import aiosqlite


class Database:
    db_path: str = ''
    connection: aiosqlite.Connection = None

    @classmethod
    def set_db_path(cls, db_path: str):
        cls.db_path = db_path

    @classmethod
    async def init(cls):
        cls.connection = await aiosqlite.connect(cls.db_path)
        await cls.execute("""CREATE TABLE IF NOT EXISTS NOTE(
                                ID INTEGER PRIMARY KEY AUTOINCREMENT,
                                TITLE TEXT,
                                CONTENT TEXT NOT NULL
                            )""")

    @classmethod
    async def shutdown(cls):
        await cls.connection.close()

    @classmethod
    async def execute(cls, sql: str, parameters: Optional[Iterable] = tuple()):
        await cls.connection.execute(sql, parameters)
        await cls.connection.commit()

    @classmethod
    async def fetch_many(cls, sql: str, parameters: Optional[Iterable] = tuple()):
        async with cls.connection.execute(sql, parameters) as cursor:
            rows = await cursor.fetchall()
            return rows

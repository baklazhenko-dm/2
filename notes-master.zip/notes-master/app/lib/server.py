from fastapi import FastAPI
from app.settings import DB_NAME
from app.routers.NoteRouter import NoteRouter
from app.lib.db import Database


def create_app(use_mocks=False) -> FastAPI:
    if use_mocks:
        Database.set_db_path(':memory:')
    else:
        Database.set_db_path(DB_NAME)
    app = FastAPI(
        title='Напоминатель',
        description='Этот сервис позволяет создавать напоминалки',
        version='0.0.1',
        on_startup=[Database.init],
        on_shutdown=[Database.shutdown]
    )
    note_router = NoteRouter()
    app.include_router(note_router, tags=['notes'])

    return app

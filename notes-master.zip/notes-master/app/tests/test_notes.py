from typing import Any

from asynctest import IsolatedAsyncioTestCase
from app.lib import create_app
from httpx import AsyncClient
from orjson import loads
from app.settings import TITLE_FROM_CONTENT_LEN

from app.lib.db import Database


class NotesCreateTestCase(IsolatedAsyncioTestCase):
    async def asyncSetUp(self) -> None:
        self.app = create_app(use_mocks=True)
        self.client = AsyncClient(app=self.app, base_url='http://test')
        await Database.init()

    async def asyncTearDown(self) -> None:
        await Database.shutdown()
        await self.client.aclose()

    async def test_can_create_note(self):
        data: dict[str, str] = {
            'title': 'string',
            'content': 'string'
        }
        resp = await self.client.post('/notes', json=data)
        self.assertEqual(resp.status_code, 201)
        body: dict[str, Any] = loads(resp.read())
        self.assertEqual(body['id'], 1)
        self.assertEqual(body['title'], 'string')
        self.assertEqual(body['content'], 'string')

    async def test_can_create_note_without_title(self):
        data: dict[str, str] = {
            'content': 'testtest'
        }
        resp = await self.client.post('/notes', json=data)
        self.assertEqual(resp.status_code, 201)
        body: dict[str, Any] = loads(resp.read())
        self.assertEqual(body['id'], 1)
        self.assertEqual(body['title'], 'testtest'[0: TITLE_FROM_CONTENT_LEN])
        self.assertEqual(body['content'], 'testtest')

    async def test_can_create_note_empty(self):
        data: dict[str, str] = {}
        resp = await self.client.post('/notes', json=data)
        self.assertEqual(resp.status_code, 422)


class NotesRetrieveTestCase(IsolatedAsyncioTestCase):
    async def asyncSetUp(self) -> None:
        self.app = create_app(use_mocks=True)
        self.client = AsyncClient(app=self.app, base_url='http://test')
        await Database.init()

    async def asyncTearDown(self) -> None:
        await Database.shutdown()
        await self.client.aclose()

    async def test_can_get_note_by_id(self):
        data: dict[str, str] = {
            'title': 'string',
            'content': 'string'
        }
        resp = await self.client.post('/notes', json=data)
        body: dict[str, Any] = loads(resp.read())
        resp2 = await self.client.get(f'/notes/{body["id"]}')
        self.assertEqual(resp2.status_code, 200)
        body2: dict[str, Any] = loads(resp2.read())
        self.assertEqual(body2['id'], 1)
        self.assertEqual(body2['title'], 'string')
        self.assertEqual(body2['content'], 'string')

    async def test_can_not_get_note_with_wrong_id(self):
        resp = await self.client.get('/notes/1')
        self.assertEqual(resp.status_code, 404)

    async def test_can_get_all_notes(self):
        data: dict[str, str] = {
            'title': 'string',
            'content': 'string'
        }
        await self.client.post('/notes', json=data)
        await self.client.post('/notes', json=data)
        resp = await self.client.get('/notes')
        self.assertEqual(resp.status_code, 200)
        body = loads(resp.read())
        self.assertEqual(len(body), 2)

    async def test_can_filter_notes(self):
        data: dict[str, str] = {
            'title': 'string',
            'content': 'string'
        }
        data2: dict[str, str] = {
            'title': 'test',
            'content': 'test'
        }
        await self.client.post('/notes', json=data)
        await self.client.post('/notes', json=data2)
        resp = await self.client.get('/notes?query=t')
        self.assertEqual(resp.status_code, 200)
        body = loads(resp.read())
        self.assertEqual(len(body), 2)
        resp2 = await self.client.get('/notes?query=tes')
        self.assertEqual(resp2.status_code, 200)
        body2 = loads(resp2.read())
        self.assertEqual(len(body2), 1)
        resp3 = await self.client.get('/notes?query=asdfa')
        self.assertEqual(resp3.status_code, 200)
        body3 = loads(resp3.read())
        self.assertEqual(len(body3), 0)


class NotesRetrieveTestCase(IsolatedAsyncioTestCase):
    async def asyncSetUp(self) -> None:
        self.app = create_app(use_mocks=True)
        self.client = AsyncClient(app=self.app, base_url='http://test')
        await Database.init()

    async def asyncTearDown(self) -> None:
        await Database.shutdown()
        await self.client.aclose()

    async def test_can_get_note_by_id(self):
        data: dict[str, str] = {
            'title': 'string',
            'content': 'string'
        }
        resp = await self.client.post('/notes', json=data)
        body: dict[str, Any] = loads(resp.read())
        resp2 = await self.client.get(f'/notes/{body["id"]}')
        self.assertEqual(resp2.status_code, 200)
        body2: dict[str, Any] = loads(resp2.read())
        self.assertEqual(body2['id'], 1)
        self.assertEqual(body2['title'], 'string')
        self.assertEqual(body2['content'], 'string')

    async def test_can_not_get_note_with_wrong_id(self):
        resp = await self.client.get('/notes/1')
        self.assertEqual(resp.status_code, 404)

    async def test_can_get_all_notes(self):
        data: dict[str, str] = {
            'title': 'string',
            'content': 'string'
        }
        await self.client.post('/notes', json=data)
        await self.client.post('/notes', json=data)
        resp = await self.client.get('/notes')
        self.assertEqual(resp.status_code, 200)
        body = loads(resp.read())
        self.assertEqual(len(body), 2)

    async def test_can_filter_notes(self):
        data: dict[str, str] = {
            'title': 'string',
            'content': 'string'
        }
        data2: dict[str, str] = {
            'title': 'test',
            'content': 'test'
        }
        await self.client.post('/notes', json=data)
        await self.client.post('/notes', json=data2)
        resp = await self.client.get('/notes?query=t')
        self.assertEqual(resp.status_code, 200)
        body = loads(resp.read())
        self.assertEqual(len(body), 2)
        resp2 = await self.client.get('/notes?query=tes')
        self.assertEqual(resp2.status_code, 200)
        body2 = loads(resp2.read())
        self.assertEqual(len(body2), 1)
        resp3 = await self.client.get('/notes?query=asdfa')
        self.assertEqual(resp3.status_code, 200)
        body3 = loads(resp3.read())
        self.assertEqual(len(body3), 0)


class NotesDeleteTestCase(IsolatedAsyncioTestCase):
    async def asyncSetUp(self) -> None:
        self.app = create_app(use_mocks=True)
        self.client = AsyncClient(app=self.app, base_url='http://test')
        await Database.init()

    async def asyncTearDown(self) -> None:
        await Database.shutdown()
        await self.client.aclose()

    async def test_can_delete_note_by_id(self):
        data: dict[str, str] = {
            'title': 'string',
            'content': 'string'
        }
        resp = await self.client.post('/notes', json=data)
        body: dict[str, Any] = loads(resp.read())
        resp2 = await self.client.delete(f'/notes/{body["id"]}')
        self.assertEqual(resp2.status_code, 204)
        resp3 = await self.client.get(f'/notes/{body["id"]}')
        self.assertEqual(resp3.status_code, 404)

    async def test_can_not_delete_note_with_wrong_id(self):
        resp = await self.client.delete(f'/notes/1')
        self.assertEqual(resp.status_code, 404)


class NotesUpdateTestCase(IsolatedAsyncioTestCase):
    async def asyncSetUp(self) -> None:
        self.app = create_app(use_mocks=True)
        self.client = AsyncClient(app=self.app, base_url='http://test')
        await Database.init()

    async def asyncTearDown(self) -> None:
        await Database.shutdown()
        await self.client.aclose()

    async def test_can_update_note_by_id(self):
        data: dict[str, str] = {
            'title': 'string',
            'content': 'string'
        }
        data2: dict[str, str] = {
            'title': 'test',
            'content': 'test'
        }
        resp = await self.client.post('/notes', json=data)
        body: dict[str, Any] = loads(resp.read())
        resp2 = await self.client.put(f'/notes/{body["id"]}', json=data2)
        self.assertEqual(resp2.status_code, 200)
        body2: dict[str, Any] = loads(resp2.read())
        self.assertEqual(body2['title'], 'test')
        self.assertEqual(body2['content'], 'test')

    async def test_can_update_note_by_id_with_no_title(self):
        data: dict[str, str] = {
            'content': 'string'
        }
        data2: dict[str, str] = {
            'content': 'testtest'
        }
        resp = await self.client.post('/notes', json=data)
        body: dict[str, Any] = loads(resp.read())
        resp2 = await self.client.put(f'/notes/{body["id"]}', json=data2)
        self.assertEqual(resp2.status_code, 200)
        body2: dict[str, Any] = loads(resp2.read())
        self.assertEqual(body2['title'], 'testtest'[0:TITLE_FROM_CONTENT_LEN])
        self.assertEqual(body2['content'], 'testtest')

    async def test_can_not_update_note_with_wrong_id(self):
        data: dict[str, str] = {
            'title': 'string',
            'content': 'string'
        }
        resp = await self.client.put(f'/notes/1', json=data)
        self.assertEqual(resp.status_code, 404)

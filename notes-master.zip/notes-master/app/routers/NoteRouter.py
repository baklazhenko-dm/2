from typing import Type, List, Optional
from fastapi import APIRouter, Path, Query
from app.controllers.NotesController import NotesController
from app.schemas.Note import Note
from app.schemas.NewNote import NewNote
from app.lib.logger import logger


class NoteRouter(APIRouter):
    def __init__(self):
        super().__init__(prefix='/notes')
        self.controller: NotesController = NotesController()
        self.post('',
                  status_code=201,
                  response_model=Note,
                  name='Создать заметку',
                  description='Метод позволяет создавать заметку'
                  )(self.create_note)
        self.get('',
                 status_code=200,
                 response_model=List[Note],
                 name='Все заметки',
                 description='Метод позволяет получить список всех заметок'
                 )(self.get_notes)
        self.get('/{note_id}',
                 status_code=200,
                 response_model=Note,
                 name='Заметка по идентификатору',
                 description='Метод позволяет получить заметку по её идентификатору'
                 )(self.get_note_by_id)
        self.put('/{note_id}',
                 status_code=200,
                 response_model=Note,
                 name='Изменить заметку',
                 description='Метод позволяет изменить заметку по её идентификатору'
                 )(self.update_note_by_id)
        self.delete('/{note_id}',
                    status_code=204,
                    name='Удаление заметки',
                    description='Метод позволяет удалить заметку по её идентификатору'
                    )(self.delete_note_by_id)

    async def create_note(self, new_note: NewNote) -> Note:
        note = await self.controller.create_note(new_note)
        return note

    async def update_note_by_id(self, new_note: NewNote, note_id: int = Path(..., title='Идентификатор заметки')) -> Note:
        note = await self.controller.update_note_by_id(note_id, new_note)
        return note

    async def get_note_by_id(self, note_id: int = Path(..., title='Идентификатор заметки')) -> Note:
        note = await self.controller.get_note_by_id(note_id)
        return note

    async def get_notes(self, query: Optional[str] = Query(default=None, title='Поиск по заметкам')) -> List[Note]:
        notes = await self.controller.get_notes(query)
        return notes

    async def delete_note_by_id(self, note_id: int = Path(..., title='Идентификатор заметки')) -> None:
        await self.controller.delete_note_by_id(note_id)
